/*
 *  Copyright 2015 Adobe Systems Incorporated
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

(function(window, hobs) {


    // Dispatch "w" key press over test window
    function dispatchKeyPress() {
        var e = new KeyboardEvent("keyup", {bubbles : true, cancelable : true, key : "w", char : "w"})
        delete e.keyCode;
        Object.defineProperty(e, "keyCode", {"value" : 87});
        hobs.window.dispatchEvent(e);
    }


    new hobs.TestSuite("Timing UI Widget", {path:"/etc/clientlibs/timing/tests/timingTests.js"})

        .addTestCase(new hobs.TestCase("Widget not visible by default")
            .navigateTo("/projects.html")
            .asserts.visible("#timing-ui-widget", false)
        )

        .addTestCase(new hobs.TestCase("Toggle widget via API call")
            .navigateTo("/projects.html")
            .asserts.visible("#timing-ui-widget", false)
            .execSyncFct(function() {
                hobs.window.timing.ui.toggle();
            })
            .asserts.visible("#timing-ui-widget")
            .execSyncFct(function() {
                hobs.window.timing.ui.toggle();
            })
            .asserts.visible("#timing-ui-widget", false)
        )

        .addTestCase(new hobs.TestCase("Toggle widget via keyboard shortcut")
            .navigateTo("/projects.html")
            .asserts.visible("#timing-ui-widget", false)
            .execSyncFct(function() {
                dispatchKeyPress();
            })
            .asserts.visible("#timing-ui-widget")
            .execSyncFct(function() {
                dispatchKeyPress();
            })
            .asserts.visible("#timing-ui-widget", false)
        );

})(window, window.hobs);
