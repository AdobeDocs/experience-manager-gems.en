Demo Script
===========



Install Sonar
-------------

* Brew it
* Start
* Install Javascript Plugin (http://localhost:9000)
* Restart



Sample Project
--------------

* Explain project code

#### Build lib
* npm install
* grunt build-lib

#### Demo Widget
* mvn clean install content-package:install
* Load http://localhost:4502
* "w" toggle timing widget



Static code analysis of the lib
-------------------------------

#### SonarQube
* uncomment sonarRunner grunt task
* grunt sonarRunner
* Check project on Sonar
* Modify project dashboard
  * Add Timeline widget
  * Set tech debt, ut line coverage, it line coverage
* Highlight Issues


#### Local Linting
* Uncomment eslint grunt task
* grunt eslint
* -> Build fails because of errors
  * Fix semicolon Issues
  * Modify quotes rule -> single quote
* grunt eslint
* -> Build passes
* grunt sonarRunner
* -> On Sonar, technical debt improve
* Add eslint to build-lib task



Unit Testing
------------

#### Execute UTs
* uncomment karma grunt task
* grunt karma:tests
* -> Tests are executed, all green

#### UT Coverage, locally
* uncomment coverage sections in karma conf file
* grunt karma:tests
* -> Tests are executed, all green
* -> Coverage report, build passes

#### UT Coverage, SonarQube
* lcov report available locally + sonarRunner task configured to pick ut lcov report   so
* grunt sonarRunner
* -> UT coverage data in Sonar widgets

#### Fails build when UT Coverage too low
* uncomment check section in karma conf
* grunt karma:tests
* -> Tests are executed, all green
* -> Coverage report, build fails because unsufficient coverage

#### Fix coverage locally
* Uncomment extra unit tests
* grunt karma:tests
* -> Tests are executed, all green
* -> Coverage report, build passes

#### UT Coverage, SonarQube (bis)
* lcov report available locally so
* grunt sonarRunner
* -> UT coverage improved in timeline widget

#### _**BONUS**_ Native browser execution
* uncomment firefox in browsers section of karma conf files
* comment PhantomJS
* grunt karma:test
* -> Firefox window opens during UTs execution

#### _**BONUS**_ Maven build
* copy mvn/pom.xml to lib root
* mvn clean install
* -> maven installs node/npm/grunt then executes grunt ut-sonar



Integration Testing
-------------------

#### Install content package with lib code instrumented
* uncomment instrument and makeReport grunt tasks
* grunt build-lib-instr-code
* mvn clean install -f ../content/pom.xml content-package:install

#### Collect coverage w/out IT execution
* Reload http://localhost:4502 to get window.__coverage__
* JSON.stringify(hobs.window.__coverage__)
* Copy paste result data in lib/coverage/it-coverage.json file

#### Analyse IT Coverage on SonarQube
* grunt makeReport
* grunt sonarRunner
* -> On Sonar TImeline widget shows IT coverage
* Highlight lines missing coverage

#### Collect coverage after IT execution
* Load http://localhost:4502/editor.html/projects.html
* Execute Timing UI Widget test suite
* JSON.stringify(hobs.window.__coverage__)
* Copy paste result data in lib/coverage/it-coverage.json file

#### Analyse IT Coverage on SonarQube
* grunt makeReport
* grunt sonarRunner
* -> On Sonar highlight IT Coverage improvment in Timeline widget
* Highlight new lines covered
