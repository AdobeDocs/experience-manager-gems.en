Javascript project Quality Metrics
==================================



Requirements
------------

* **Node.js** Javascript runtime **~** Execute js code outside of browsers)

* **npm** Node Package Manager (comes with Node.js installation)

* **Grunt** The Javascript Task Runner **~** Automate Javascript project builds

* **SonarQube** Open platform to manage code quality



#### OSX Kickstart

Requires [Homebrew](http://brew.sh/) CLI, The missing package manager for OS X

Then, from Terminal:

##### Node.js (+ npm)
```
brew install nodejs
```

##### Grunt
```
npm install -g grunt-cli
```

##### SonarQube

**Install** Sonar
```
brew install sonar
```

**Start** Sonar
```
sonar console
```

(`Ctrl-C` to stop)

**Access** Sonar

Web interface @ http://localhost:9000


##### Install Javascript SonarQube plugin (Javascript static code analysis rules)

From the web interface:

1. Login as *admin* (`admin` / `admin`)

2. Navigate to `Settings` > `System` > `Update Center` > `Available Plugins`

3. In *LANGUAGES* section, click on *Javascript*

4. Click on *Install* button

5. Restart Sonar

6. Check plugin installation @ `Settings` > `System` > `Update Center` > `Installed Plugins`



Build Js Library
----------------

From lib/

```
npm install
```

will install all the grunt tasks modules locally

```
grunt build-lib
```

will:
1. delete previous build
2. execute linting using rules from `lib/conf/eslint.conf.json`
3. concatenate js files in single lib `build/timing.js`



Static Code Analysis
--------------------

#### SonarQube
```
grunt sonarRunner
```

will:
1. run SonarQube analysis @ http://localhost:9000


#### Local linting
```
grunt eslint
```

will:
1. execute linting using rules from `lib/conf/eslint.conf.json`



Unit Testing + Coverage
-----------------------

#### Execute Unit Tests + compute coverage locally
```
grunt karma:test
```

will:
1. Instrument js files to enable test coverage collection
2. Execute UTs (`lib/tests/test.timing.js`) on headless browser PhantomJs
3. Generates coverage reports: HTML (`lib/coverage/ut/html/index.html`) and lcov file (`lib/coverage/ut/lcov/lcov.info`)


#### Execute Unit Tests + coverage analysis on SonarQube
```
grunt ut-sonar
```

will:
1. execute `grunt karma:test`
2. execute `grunt sonarRunner` (using `lib/coverage/lcov/lcov.info` for UT coverage)


#### [Maven] Execute Unit Tests + coverage analysis on SonarQube
```
mvn clean install
```

will:
1. execute maven-frontend-plugin
  1. install node / npm / grunt locally
  2. execute `npm install` via Maven
  3. execute `grunt ut-sonar` via Maven


Complete Build
--------------
```
grunt full
```

will execute following Grunt tasks:
[`build-lib`, `ut-sonar`]

(equivalent to [`clean`, `eslint`, `concat:dist`, `karma:test`, `sonarRunner`])



Integration/E2E UI Testing + Coverage
-------------------------------------

1. Build the lib with js code instrumented (to collect IT coverage)
```
grunt build-lib-instr-code
```
`build/timing.js` now contains instrumented code

2. Install content package + tests on AEM
```
mvn clean install -f content/pom.xml content-package:install
```
Maven will pick timing.js from `lib/build/timing.js` and copy it to the clientlib folder

3. Execute UI tests from AEM

    Navigate to the testrunner page (in authoring, Developer Mode):

    * Load AEM Editor page http://localhost:4502/editor.html/projects.html
    * Switch to _Developer_ layer
    * In the side panel, select _Tests_ tab (middle)

    From the testrunner, execute the _**Timing UI Widget**_ test suite

4. Collect coverage data

From the web console (in the browser's developer tools), type:
```
JSON.stringify(hobs.window.__coverage__)
```

Copy the result data
`{"src/timing.js":{"path":"src/timing.js",  [...]  ,"column":8}}]}}}}`

Replace content of `lib/coverage/it-coverage.json` with the copied data

5. Generate it lcov report from the collected data
```
grunt makeReport
```

LCOV report is generated into `lib/coverage/it/lcov.info`

6. Execute Sonar analysis
```
grunt sonarRunner
```

The task is configured to pick:
* ut coverage from `coverage/ut/lcov/lcov.info`
* it coverage from `coverage/it/lcov.info`
